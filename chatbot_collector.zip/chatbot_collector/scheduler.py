from apscheduler.schedulers.background import BackgroundScheduler
import asyncio
from api_service import fetch_and_save

scheduler = BackgroundScheduler()

def start_scheduler():
    scheduler.add_job(lambda: asyncio.run(fetch_and_save()), "cron", hour=1, minute=30)  # run 4 AM
    scheduler.start()