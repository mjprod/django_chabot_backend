import httpx
from datetime import datetime, timedelta
from database import collection

API_URL = "https://joker2api728.com/chatbot2025/v1/ChatBot/LiveConvsersationWithBotReply"

async def fetch_and_save():
    date_to = (datetime.today() - timedelta(days=1)).strftime("%Y-%m-%d")
    date_fr = (datetime.today() - timedelta(days=2)).strftime("%Y-%m-%d")

    params = {"dateFr": date_fr, "dateTo": date_to}

    async with httpx.AsyncClient() as client:
        response = await client.get(API_URL, params=params)

    data = response.json()

    if data.get("ResponseCode") == 200 and "ResponseData" in data:
        saved_data = {"dateFr": date_fr, "dateTo": date_to, "ResponseData": data["ResponseData"]}
        await collection.insert_one(saved_data)
        return {"message": "Data saved", "data": saved_data}
    
    return {"error": "API response invalid"}