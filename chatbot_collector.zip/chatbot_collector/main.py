from fastapi import FastAPI, HTTPException
import asyncio
from api_service import fetch_and_save
from scheduler import start_scheduler

app = FastAPI()

@app.on_event("startup")
async def startup_event():
    """Starts the scheduler when the API starts"""
    loop = asyncio.get_event_loop()
    loop.create_task(start_scheduler())

@app.get("/fetch-data")
async def fetch_data():
    """Endpoint to fetch and save data"""
    try:
        data = await fetch_and_save()
        return {"status": "success", "data": data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
async def root():
    """Root endpoint to check if the API is running"""
    return {"message": "API is running"}