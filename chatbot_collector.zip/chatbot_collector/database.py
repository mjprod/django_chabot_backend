from motor.motor_asyncio import AsyncIOMotorClient
import asyncio

MONGODB_URI = "mongodb+srv://dev:Yrr0szjwTuE1BU7Y@chatbotdb-dev.0bcs2.mongodb.net/chatbotdb?retryWrites=true&w=majority&tlsAllowInvalidCertificates=true"
MONGODB_NAME = "chatbotdb"
COLLECTION_NAME = "ck_old_conversations"

client = AsyncIOMotorClient(MONGODB_URI)
db = client[MONGODB_NAME]
collection = db[COLLECTION_NAME]